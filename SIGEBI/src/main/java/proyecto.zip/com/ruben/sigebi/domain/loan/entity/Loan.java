package com.ruben.sigebi.domain.loan.entity;
import com.ruben.sigebi.domain.User.valueObject.UserId;
import com.ruben.sigebi.domain.bibliographyResource.valueObject.ResourceCopyId;
import com.ruben.sigebi.domain.bibliographyResource.valueObject.ResourceID;
import com.ruben.sigebi.domain.common.exception.InvalidFieldException;
import com.ruben.sigebi.domain.common.exception.InvalidStateException;
import com.ruben.sigebi.domain.common.objectValue.ActivatableAggregate;
import com.ruben.sigebi.domain.loan.enums.PendingState;
import com.ruben.sigebi.domain.loan.events.LoanCreated;
import com.ruben.sigebi.domain.loan.events.LoanOverdue;
import com.ruben.sigebi.domain.loan.events.LoanReturned;
import com.ruben.sigebi.domain.loan.exception.BusinessLoanViolationException;
import com.ruben.sigebi.domain.loan.valueObjects.LoanId;

import java.time.Duration;
import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

public class Loan extends ActivatableAggregate {
    private final LoanId loanID;
    private final UserId userId;
    private final ResourceCopyId copyId;
    private final Instant startDate;
    private Instant dueDate;
    private PendingState pendingState;


    public Loan(UserId userId, UUID loanId, ResourceCopyId copyId, Instant endDate) {
        this.userId = Objects.requireNonNull(userId);
        this.copyId = Objects.requireNonNull(copyId);
        this.startDate = Instant.now();
        this.dueDate = Objects.requireNonNull(endDate);
        Objects.requireNonNull(loanId);
        this.loanID = new LoanId(loanId);
        this.pendingState = PendingState.ON_TIME;
        activate();
    }


    public Loan(LoanId loanID, UserId userId, ResourceCopyId copyId,
                Instant startDate, Instant dueDate, PendingState pendingState) {
        this.loanID = Objects.requireNonNull(loanID);
        this.userId = Objects.requireNonNull(userId);
        this.copyId = Objects.requireNonNull(copyId);
        this.startDate = Objects.requireNonNull(startDate);
        this.dueDate = Objects.requireNonNull(dueDate);
        this.pendingState = Objects.requireNonNull(pendingState);
    }

    public PendingState getPendingState() {
        return pendingState;
    }

    public void extendDueDate(int days) {
        if (days < 1) {
            throw new InvalidFieldException("cannot put negative or zero days: " + days);
        }
        if (!isActive()) {
            throw new InvalidStateException("Loan cannot be extended while inactive: " + this.getStatus());
        }
        if (this.dueDate.isBefore(Instant.now())) {
            throw new BusinessLoanViolationException("Loan cannot be extended after it is overdue: "
                    + "Today: " + Instant.now() + " Due date: " + this.dueDate);
        }
        this.dueDate = this.dueDate.plus(Duration.ofDays(days));
    }

    public boolean isOverdue() {
        return this.pendingState.equals(PendingState.OVERDUE);
    }

    public void returnLoan(Instant returnedAt) {
        Objects.requireNonNull(returnedAt);
        if (!isActive()) {
            throw new InvalidStateException("Loan inactive: " + this.loanID);
        }
        deactivate();
//        addDomainEvent(new LoanReturned(getCopyId(), getLoanID(), getUserId(), returnedAt));
    }

    public void markAsOverdue() {
        if (!Instant.now().isAfter(this.dueDate)) {
            throw new BusinessLoanViolationException("Cannot mark as overdue before the due date.");
        }
        if (isOverdue()) {
            throw new BusinessLoanViolationException("Loan is already marked as overdue");
        }
        if (!isActive()) {
            throw new InvalidStateException("Loan is inactive");
        }
        this.pendingState = PendingState.OVERDUE;
//        addDomainEvent(new LoanOverdue(getCopyId(), getLoanID(), getUserId(), Instant.now()));
    }

    public LoanId getLoanID() {
        return loanID;
    }

    public UserId getUserId() {
        return userId;
    }

    public ResourceCopyId getCopyId() {
        return copyId;
    }

    public Instant getStartDate() {
        return startDate;
    }

    public Instant getDueDate() {
        return dueDate;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Loan loan = (Loan) o;
        return getLoanID().equals(loan.getLoanID());
    }

    @Override
    public int hashCode() {
        return getLoanID().hashCode();
    }
}
